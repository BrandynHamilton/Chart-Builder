# A Library for High-Quality, Reproducable Charts

- This library builds off Plotly and automates portions of data cleaning and charting for users.
- A user only inputs specified parameters such as chart type and columns to chart, enabling quick charting of complex data structures.
